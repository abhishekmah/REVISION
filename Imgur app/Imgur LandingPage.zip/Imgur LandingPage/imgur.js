var div1 = document.getElementById("div1");
var div2 = document.getElementById("div2");
var div3 = document.getElementById("div3");
var div4 = document.getElementById("div4");
var div5 = document.getElementById("div5");

async function handleSearch () {
    var search = document.getElementById("search").value;
    try{
        let res = await fetch(`https://api.unsplash.com/search/photos?per_page=1000&query=${search}&client_id=5nE8UeK6Y0ZOergG68ml18Q9F5tSHivP1vI9IBlDvuc`)
        // let data = res.data.results;
        var items = await res.json();
        console.log("items:",items)
        appendImages(items.results);
        }
        catch(e){
            console.log("e:",e)
        }
        
        // console.log(search);
        console.log("Button Clicked");
    }
    
    function appendImages(items){
    div1.innerHTML = null
    div2.innerHTML = null
    div3.innerHTML = null
    div4.innerHTML = null
    div5.innerHTML = null

    let arr1=[],arr2=[],arr3=[],arr4=[],arr5=[];

    let x = Math.floor(items.length/5);

    for(let i=0; i<x; i++)
    arr1.push(items[i]);
    for(let i=x; i<(2*x); i++)
    arr2.push(items[i]);
    for(let i=2*x; i<(3*x); i++)
    arr3.push(items[i]);
    for(let i=3*x; i<(4*x); i++)
    arr4.push(items[i]);
    for(let i=4*x; i<items.length; i++)
    arr5.push(items[i]);

    arr1.forEach((el)  => {

        let div = document.createElement('div')
        div.setAttribute("class", "imgDiv")

        let img = document.createElement('img')
        img.src = el.urls.small;
        img.style.width="100%";

        let para = document.createElement('p')
        para.innerHTML = el.alt_description;

        div.append(img, para);
        div1.append(div)
    })

    arr2.forEach((el)  => {

        let div = document.createElement('div')
        div.setAttribute("class", "imgDiv")

        let img = document.createElement('img')
        img.src = el.urls.small;
        img.style.width="100%";

        let para = document.createElement('p')
        para.innerHTML = el.alt_description;

        div.append(img, para);
        div2.append(div)
    })

    arr3.forEach((el)  => {

        let div = document.createElement('div')
        div.setAttribute("class", "imgDiv")

        let img = document.createElement('img')
        img.src = el.urls.small;
        img.style.width="100%";

        let para = document.createElement('p')
        para.innerHTML = el.alt_description;

        div.append(img, para);
        div3.append(div)
    })

    arr4.forEach((el)  => {

        let div = document.createElement('div')
        div.setAttribute("class", "imgDiv")

        let img = document.createElement('img')
        img.src = el.urls.small;
        img.style.width="100%";

        let para = document.createElement('p')
        para.innerHTML = el.alt_description;

        div.append(img, para);
        div4.append(div)
    })

    arr5.forEach((el)  => {

        let div = document.createElement('div')
        div.setAttribute("class", "imgDiv")

        let img = document.createElement('img')
        img.src = el.urls.small;
        img.style.width="100%";

        let para = document.createElement('p')
        para.innerHTML = el.alt_description;

        div.append(img, para);
        div5.append(div)
    })
}